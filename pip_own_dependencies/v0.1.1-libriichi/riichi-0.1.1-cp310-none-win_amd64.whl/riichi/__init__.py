from .riichi import *

__doc__ = riichi.__doc__
if hasattr(riichi, "__all__"):
    __all__ = riichi.__all__